n = 5
result = ""


n.times do |i|
    result += (i+1).to_s
    puts result
end
